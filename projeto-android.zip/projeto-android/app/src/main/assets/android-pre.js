/* O WebView do Android não tem síntese de voz: usa a voz nativa do aparelho. */
(function(){
  if(!window.AndroidApp) return;
  const pending = new Map();
  let next = 0;
  function Utterance(text){ this.text = text; this.rate = 1; this.voice = null; }
  const synth = {
    getVoices(){ try{ return JSON.parse(AndroidApp.voices()); }catch(e){ return []; } },
    speak(u){
      const id = "u" + (++next);
      pending.set(id, u);
      AndroidApp.speak(id, u.text, u.rate, u.voice ? u.voice.name : "");
    },
    cancel(){
      AndroidApp.stopSpeaking();
      const old = [...pending.values()];
      pending.clear();
      old.forEach(u => u.onend && u.onend());
    }
  };
  window.__ttsDone = id => {
    const u = pending.get(id);
    pending.delete(id);
    if(u && u.onend) u.onend();
  };
  Object.defineProperty(window, "speechSynthesis", {value:synth, configurable:true});
  Object.defineProperty(window, "SpeechSynthesisUtterance", {value:Utterance, configurable:true, writable:true});
})();
