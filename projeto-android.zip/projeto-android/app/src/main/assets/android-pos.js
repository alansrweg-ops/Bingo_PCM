/* Ajustes feitos depois que o jogo carrega: impressão, arquivos e botão voltar. */
(function(){
  if(!window.AndroidApp) return;
  window.print = () => {
    const report = !!document.getElementById("reportPage");
    AndroidApp.print(state.config.name + (report ? " - Relatório" : " - Cartelas"), report);
  };
  window.__printDone = () => window.dispatchEvent(new Event("afterprint"));
  window.download = (name, text, type) => AndroidApp.save(name, text, type);
  window.__back = () => {
    if(!document.getElementById("overlay").classList.contains("open")) return false;
    stopVoice(); closeModal();
    return true;
  };
  document.getElementById("btnFull").hidden = true; /* o app já abre em tela cheia */
})();
