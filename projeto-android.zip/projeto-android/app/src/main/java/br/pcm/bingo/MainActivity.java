package br.pcm.bingo;

import android.app.Activity;
import android.app.AlertDialog;
import android.content.ActivityNotFoundException;
import android.content.Context;
import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.os.CancellationSignal;
import android.os.ParcelFileDescriptor;
import android.print.PageRange;
import android.print.PrintAttributes;
import android.print.PrintDocumentAdapter;
import android.print.PrintManager;
import android.speech.tts.TextToSpeech;
import android.speech.tts.UtteranceProgressListener;
import android.speech.tts.Voice;
import android.view.View;
import android.view.WindowManager;
import android.webkit.JavascriptInterface;
import android.webkit.ValueCallback;
import android.webkit.WebChromeClient;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.Toast;

import org.json.JSONArray;
import org.json.JSONObject;

import java.io.OutputStream;
import java.nio.charset.StandardCharsets;
import java.util.Locale;

public class MainActivity extends Activity {
    private static final int PICK_FILE = 1;
    private static final int SAVE_FILE = 2;

    private WebView web;
    private TextToSpeech tts;
    private volatile boolean ttsReady = false;
    private ValueCallback<Uri[]> fileCallback;
    private String textToSave;

    @Override
    protected void onCreate(Bundle saved) {
        super.onCreate(saved);
        getWindow().addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON);

        web = new WebView(this);
        setContentView(web);

        WebSettings s = web.getSettings();
        s.setJavaScriptEnabled(true);
        s.setDomStorageEnabled(true); // guarda cartelas, sorteio e configurações
        s.setUseWideViewPort(true);
        s.setTextZoom(100); // a fonte do sistema não desmonta a tela
        s.setAllowFileAccess(true);

        web.addJavascriptInterface(new Bridge(), "AndroidApp");
        web.setWebViewClient(new WebViewClient() {
            @Override
            public boolean shouldOverrideUrlLoading(WebView view, android.webkit.WebResourceRequest request) {
                // o app só exibe as próprias páginas
                return !request.getUrl().toString().startsWith("file:///android_asset/");
            }
        });
        web.setWebChromeClient(new WebChromeClient() {
            @Override
            public boolean onShowFileChooser(WebView view, ValueCallback<Uri[]> callback, FileChooserParams params) {
                if (fileCallback != null) fileCallback.onReceiveValue(null);
                fileCallback = callback;
                boolean image = false;
                for (String type : params.getAcceptTypes()) {
                    if (type.startsWith("image/")) image = true;
                }
                Intent intent = new Intent(Intent.ACTION_GET_CONTENT);
                intent.addCategory(Intent.CATEGORY_OPENABLE);
                // arquivos .json nem sempre são reconhecidos, por isso */*
                intent.setType(image ? "image/*" : "*/*");
                try {
                    startActivityForResult(intent, PICK_FILE);
                } catch (ActivityNotFoundException e) {
                    fileCallback = null;
                    return false;
                }
                return true;
            }
        });

        tts = new TextToSpeech(this, status -> {
            if (status != TextToSpeech.SUCCESS) return;
            tts.setLanguage(new Locale("pt", "BR"));
            tts.setOnUtteranceProgressListener(new UtteranceProgressListener() {
                @Override public void onStart(String id) { }
                @Override public void onDone(String id) { finishedSpeaking(id); }
                @Override public void onError(String id) { finishedSpeaking(id); }
            });
            ttsReady = true;
        });

        web.loadUrl("file:///android_asset/index.html");
    }

    private void run(String script) {
        runOnUiThread(() -> {
            if (web != null) web.evaluateJavascript(script, null);
        });
    }

    private void finishedSpeaking(String id) {
        run("window.__ttsDone && window.__ttsDone(" + JSONObject.quote(id) + ")");
    }

    private void toast(String message) {
        Toast.makeText(this, message, Toast.LENGTH_LONG).show();
    }

    /** Funções que a página chama no Android. */
    private class Bridge {
        @JavascriptInterface
        public void speak(String id, String text, float rate, String voiceName) {
            if (!ttsReady) {
                finishedSpeaking(id);
                return;
            }
            try {
                tts.setLanguage(new Locale("pt", "BR"));
                if (voiceName != null && !voiceName.isEmpty() && tts.getVoices() != null) {
                    for (Voice v : tts.getVoices()) {
                        if (v.getName().equals(voiceName)) tts.setVoice(v);
                    }
                }
                tts.setSpeechRate(rate);
                if (tts.speak(text, TextToSpeech.QUEUE_FLUSH, null, id) != TextToSpeech.SUCCESS) {
                    finishedSpeaking(id);
                }
            } catch (Exception e) {
                finishedSpeaking(id);
            }
        }

        @JavascriptInterface
        public void stopSpeaking() {
            if (ttsReady) tts.stop();
        }

        @JavascriptInterface
        public String voices() {
            JSONArray list = new JSONArray();
            try {
                if (ttsReady && tts.getVoices() != null) {
                    for (Voice v : tts.getVoices()) {
                        if (!"pt".equals(v.getLocale().getLanguage())) continue;
                        JSONObject item = new JSONObject();
                        item.put("name", v.getName());
                        item.put("lang", v.getLocale().toLanguageTag());
                        list.put(item);
                    }
                }
            } catch (Exception ignored) {
                // sem lista de vozes: o app usa a voz padrão
            }
            return list.toString();
        }

        @JavascriptInterface
        public void print(String name, boolean withMargins) {
            runOnUiThread(() -> printPage(name, withMargins));
        }

        @JavascriptInterface
        public void save(String name, String text, String mime) {
            runOnUiThread(() -> {
                textToSave = text;
                Intent intent = new Intent(Intent.ACTION_CREATE_DOCUMENT);
                intent.addCategory(Intent.CATEGORY_OPENABLE);
                intent.setType(mime.split(";")[0]);
                intent.putExtra(Intent.EXTRA_TITLE, name);
                try {
                    startActivityForResult(intent, SAVE_FILE);
                } catch (ActivityNotFoundException e) {
                    toast("Este aparelho não tem um app para salvar arquivos.");
                }
            });
        }
    }

    private void printPage(String name, boolean withMargins) {
        PrintManager manager = (PrintManager) getSystemService(Context.PRINT_SERVICE);
        final PrintDocumentAdapter inner = web.createPrintDocumentAdapter(name);

        // avisa a página só depois que a impressão terminar de usar o conteúdo
        PrintDocumentAdapter adapter = new PrintDocumentAdapter() {
            @Override
            public void onStart() {
                inner.onStart();
            }

            @Override
            public void onLayout(PrintAttributes oldAttributes, PrintAttributes newAttributes,
                                 CancellationSignal signal, LayoutResultCallback callback, Bundle extras) {
                inner.onLayout(oldAttributes, newAttributes, signal, callback, extras);
            }

            @Override
            public void onWrite(PageRange[] pages, ParcelFileDescriptor destination,
                                CancellationSignal signal, WriteResultCallback callback) {
                inner.onWrite(pages, destination, signal, callback);
            }

            @Override
            public void onFinish() {
                inner.onFinish();
                run("window.__printDone && window.__printDone()");
            }
        };

        int margin = withMargins ? 470 : 0; // milésimos de polegada (470 = 12 mm)
        PrintAttributes attributes = new PrintAttributes.Builder()
                .setMediaSize(PrintAttributes.MediaSize.ISO_A4)
                .setMinMargins(new PrintAttributes.Margins(margin, margin, margin, margin))
                .build();
        manager.print(name, adapter, attributes);
    }

    @Override
    protected void onActivityResult(int request, int result, Intent data) {
        super.onActivityResult(request, result, data);
        if (request == PICK_FILE && fileCallback != null) {
            fileCallback.onReceiveValue(WebChromeClient.FileChooserParams.parseResult(result, data));
            fileCallback = null;
        } else if (request == SAVE_FILE) {
            if (result == RESULT_OK && data != null && data.getData() != null && textToSave != null) {
                try (OutputStream out = getContentResolver().openOutputStream(data.getData(), "wt")) {
                    out.write(textToSave.getBytes(StandardCharsets.UTF_8));
                    toast("Arquivo salvo.");
                } catch (Exception e) {
                    toast("Não foi possível salvar o arquivo.");
                }
            }
            textToSave = null;
        }
    }

    @Override
    public void onWindowFocusChanged(boolean hasFocus) {
        super.onWindowFocusChanged(hasFocus);
        if (hasFocus) {
            getWindow().getDecorView().setSystemUiVisibility(
                    View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY
                            | View.SYSTEM_UI_FLAG_FULLSCREEN
                            | View.SYSTEM_UI_FLAG_HIDE_NAVIGATION
                            | View.SYSTEM_UI_FLAG_LAYOUT_STABLE);
        }
    }

    @Override
    public void onBackPressed() {
        // "voltar" fecha a janela aberta; sem janela, pede confirmação para sair
        web.evaluateJavascript("window.__back ? window.__back() : false", closed -> {
            if ("true".equals(closed)) return;
            new AlertDialog.Builder(this)
                    .setMessage("Sair do bingo? O jogo fica salvo.")
                    .setPositiveButton("Sair", (d, w) -> finish())
                    .setNegativeButton("Continuar", null)
                    .show();
        });
    }

    @Override
    protected void onStop() {
        super.onStop();
        // pausa o sorteio automático quando o app sai da tela
        run("typeof pause === 'function' && (pause(), stopVoice())");
    }

    @Override
    protected void onDestroy() {
        if (tts != null) tts.shutdown();
        if (web != null) {
            web.destroy();
            web = null;
        }
        super.onDestroy();
    }
}
